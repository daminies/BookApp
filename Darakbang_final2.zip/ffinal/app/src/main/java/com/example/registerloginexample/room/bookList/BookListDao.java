package com.example.registerloginexample.room.bookList;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BookListDao {
    @Query("SELECT * FROM BookListData")
    LiveData<List<BookListData>> getAllData();

    @Query("DELETE FROM BookListData WHERE `id`=:id")
    void deleteData(long id);

    @Query("SELECT * FROM BookListData WHERE `id`=:id")
    LiveData<BookListData> getData(long id);

    @Insert
    void insertData(BookListData bookListData);

    @Update
    void updateData(BookListData bookListData);
}
