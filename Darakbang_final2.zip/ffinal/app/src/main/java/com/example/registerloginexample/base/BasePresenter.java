package com.example.registerloginexample.base;

public interface BasePresenter {

    void start();

}
