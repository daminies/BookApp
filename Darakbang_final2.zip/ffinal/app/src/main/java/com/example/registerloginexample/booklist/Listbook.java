package com.example.registerloginexample.booklist;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Listbook implements Parcelable {
    private String list_name;
    private ArrayList<String> book;

    public Listbook(String list_name){
        this.list_name = list_name;
        book = new ArrayList<String>();
    }


    protected Listbook(Parcel in) {
        list_name = in.readString();
        book = in.createStringArrayList();
    }

    public static final Creator<Listbook> CREATOR = new Creator<Listbook>() {
        @Override
        public Listbook createFromParcel(Parcel in) { return new Listbook(in); }

        @Override
        public Listbook[] newArray(int size) { return new Listbook[size]; }
    };

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(list_name);
        dest.writeStringList(book);
    }

    public String getList_name(){ return list_name; }


    public void setList_name(String list_name){ this.list_name = list_name; }




}
