package com.example.registerloginexample.calendar

import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.example.registerloginexample.R
import com.example.registerloginexample.booklist.SearchActivity
import com.example.registerloginexample.room.book.BookData
import com.example.registerloginexample.room.book.BookDataProcess
import com.example.registerloginexample.room.book.BookDatabase
import com.example.registerloginexample.room.calendar.CalConverter
import com.example.registerloginexample.room.calendar.CalendarData
import com.example.registerloginexample.room.calendar.CalendarDatabase
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_calendar_detail.*

class CalendarDetailActivity : AppCompatActivity() {
    private var chooseNum = 0
    private lateinit var bookDataProcess: BookDataProcess
    private lateinit var date: List<String>
    private var position = 0
    private var bookDataList = arrayOfNulls<BookData>(2)
    private var data: CalendarData? = null
    private var firstFlag = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar_detail)
        date = intent.extras!!.getString("date", "").split(".")
        position = intent.getIntExtra("position", 0)
        bookDataProcess = BookDataProcess(this)

        val a = Observable.just(CalendarDatabase.getDatabase(this))
                .subscribeOn(Schedulers.io())
                .subscribe {
                    data = it.calendarDao().getData(date[0], date[1], position)
                    if (data == null) {
                        firstFlag = true
                        data = CalendarData(System.currentTimeMillis(), date[0], date[1], position, CalConverter().calToString(bookDataList.toMutableList()), getRdIndex(rg_01.checkedRadioButtonId), getRdIndex(rg_02.checkedRadioButtonId))
                    } else {
                        rg_01.check(rg_01.getChildAt(data!!.statusFirst).id)
                        rg_02.check(rg_02.getChildAt(data!!.statusSecond).id)
                        CalConverter().stringToCal(data?.bookDataList).forEachIndexed { index, bookData ->
                            setBookData(bookData, index)
                        }
                    }
                }

        BookDatabase.getInstance(this).bookDao().allData.observe(this, Observer { bookData: List<BookData> ->
            if (bookData.isNotEmpty()) {
                setBookData(bookData[bookData.size - 1], chooseNum)
                bookDataProcess.deleteData(bookData[bookData.size - 1].id)
            }
        })
        rg_01.setOnCheckedChangeListener(onCheckChangeListener)
        rg_02.setOnCheckedChangeListener(onCheckChangeListener)

        btn_search.setOnClickListener(onClickSearchListener)
        btn_search02.setOnClickListener(onClickSearchListener)
        btn_save.setOnClickListener {
            if (firstFlag) {
                Observable.just(CalendarDatabase.getDatabase(this))
                        .subscribeOn(Schedulers.io())
                        .subscribe {
                            it.calendarDao().insertCal(data)
                            finish()
                        }
            } else {
                Observable.just(CalendarDatabase.getDatabase(this))
                        .subscribeOn(Schedulers.io())
                        .subscribe {
                            it.calendarDao().updateCal(data)
                            finish()
                        }
            }
        }
        btn_clear.setOnClickListener(onClickClearListener)

        btn_clear02.setOnClickListener(onClickClearListener)
    }

    private val onClickClearListener = View.OnClickListener {
        when(it.id){
            R.id.btn_clear -> clearBookData(0)
            R.id.btn_clear02 -> clearBookData(1)
        }
    }


    private val onClickSearchListener = View.OnClickListener {
        when (it.id) {
            R.id.btn_search -> chooseNum = 0
            R.id.btn_search02 -> chooseNum = 1
        }
        startActivity(Intent(this, SearchActivity::class.java))
    }

    private val onCheckChangeListener = RadioGroup.OnCheckedChangeListener{ radioGroup, i ->
        when(radioGroup.id){
            R.id.rg_01 -> {
                data?.statusFirst = getRdIndex(i)
                //data?.statusFirst = radioGroup.indexOfChild(radioGroup.get)
            }
            R.id.rg_02 -> {
                data?.statusSecond = getRdIndex(i)
            }
        }

    }

    private fun getRdIndex(id: Int): Int {
        return when (id) {
            R.id.rd_start, R.id.rd_start02 -> 0
            R.id.rd_ing, R.id.rd_ing02 -> 1
            R.id.rd_finish, R.id.rd_finish02 -> 2
            else -> 0
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun setBookData(bookData: BookData?, index: Int) {
        if (bookData == null) return
        bookDataList[index] = bookData
        data?.bookDataList = CalConverter().calToString(bookDataList.toMutableList())
        runOnUiThread {
            when (index) {
                0 -> {
                    book_name_tv.text = Html.fromHtml(bookData.title)
                    book_author_tv.text = bookData.author
                    Glide.with(this).load(bookData.image).into(book_img)
                }
                1 -> {
                    book_name_tv02.text = Html.fromHtml(bookData.title)
                    book_author_tv02.text = bookData.author
                    Glide.with(this).load(bookData.image).into(book_img02)
                }
            }
        }
    }

    private fun clearBookData(index: Int) {
        bookDataList[index] = null
        data?.bookDataList = CalConverter().calToString(bookDataList.toMutableList())
        runOnUiThread {
            when (index) {
                0 -> {
                    book_name_tv.text = ""
                    book_author_tv.text = ""
                    Glide.with(this).load(R.drawable.book).into(book_img)
                    rg_01.check(rd_start.id)
                }
                1 -> {
                    book_name_tv02.text = ""
                    book_author_tv02.text = ""
                    Glide.with(this).load(R.drawable.book).into(book_img02)
                    rg_02.check(rd_start02.id)
                }
            }
        }
    }

}