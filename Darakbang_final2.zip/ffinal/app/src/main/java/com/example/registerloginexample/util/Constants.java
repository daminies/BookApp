package com.example.registerloginexample.util;

public class Constants {

    public static final String MOVIE_URL = "MOVIE_URL";
    public static final int MOVIE_DISPLAY_SIZE = 100;
}
