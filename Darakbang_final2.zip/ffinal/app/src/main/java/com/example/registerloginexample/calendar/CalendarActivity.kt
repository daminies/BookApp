package com.example.registerloginexample.calendar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.registerloginexample.R
import kotlinx.android.synthetic.main.activity_calendar.*

class CalendarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)
        calendar_view.setClickListener(object : CalendarClickListener {
            override fun onClick(date: String , position : Int) {
                val intent = Intent(applicationContext,CalendarDetailActivity::class.java)
                intent.putExtra("date",date)
                intent.putExtra("position",position)
                startActivity(intent)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        calendar_view.loadData()
    }
}