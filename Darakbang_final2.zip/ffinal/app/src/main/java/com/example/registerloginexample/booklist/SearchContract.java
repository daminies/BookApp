package com.example.registerloginexample.booklist;

import com.example.registerloginexample.base.BasePresenter;
import com.example.registerloginexample.base.BaseView;
import com.example.registerloginexample.repository.Item;

import java.util.ArrayList;

public interface SearchContract {

    interface View extends BaseView<Presenter> {

        void showEmptyField();
        void showNotFindItem();
        void showBookPage(int position);
        void showMoreBooks(ArrayList<Item> items);
        void showNewBooks(ArrayList<Item> items);

    }

    interface Presenter extends BasePresenter {

        void startSearch(String title);
        void getBooks(String title, int startPosition);

    }

}
