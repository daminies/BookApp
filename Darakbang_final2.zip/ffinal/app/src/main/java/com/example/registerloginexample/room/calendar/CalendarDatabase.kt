package com.example.registerloginexample.room.calendar

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities= [CalendarData::class],version = 1)
abstract class CalendarDatabase : RoomDatabase(){
    abstract fun calendarDao(): CalendarDao

    companion object{
        private var database: CalendarDatabase? = null

        private const val ROOM_DB = "calendar.db"

        fun getDatabase(context: Context): CalendarDatabase {
            if(database ==null){
                database = Room.databaseBuilder(
                    context.applicationContext,
                    CalendarDatabase::class.java, ROOM_DB
                ).fallbackToDestructiveMigration().build()
            }
            return database!!
        }
    }
}