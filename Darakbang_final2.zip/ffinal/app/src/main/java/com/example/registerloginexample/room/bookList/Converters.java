package com.example.registerloginexample.room.bookList;

import androidx.room.TypeConverter;

import com.example.registerloginexample.room.book.BookData;
import com.example.registerloginexample.room.calendar.CalendarData;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class Converters {
    @TypeConverter
    public static List<BookData> fromString(String value) {
        Type listType = new TypeToken<List<BookData>>() {}.getType();
        return new Gson().fromJson(value, listType);
    }

    @TypeConverter
    public static String fromArrayList(List<BookData> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);
        return json;
    }


}
