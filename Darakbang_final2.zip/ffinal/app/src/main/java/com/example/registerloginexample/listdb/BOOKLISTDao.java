package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface BOOKLISTDao {

    //@Query("SELECT * FROM LIST LEFT JOIN BOOK ON LIST.listId")

    @Query("SELECT * FROM LISTEntity " +
            "INNER JOIN BOOKEntity ON LISTEntity.listId = BOOKEntity.listIdx " +
            "WHERE LISTEntity.listName LIKE :")




    @Insert
    public void insertBooksAndLists(BOOKEntity books, List<BOOKEntity> lists);
}
*/