package com.example.registerloginexample.room.calendar

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class CalendarData( @PrimaryKey val id :Long, val year:String, val month:String, val position : Int, var bookDataList : String, var statusFirst : Int, var statusSecond : Int)