package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class BOOKEntity {
    @PrimaryKey
    public int listIdx;

    public String author;

    public String title;

    public String publisher;

    public String description;

    public String imageuri;

    public int getListIdx() {
        return listIdx;
    }

    public void setListIdx(int listIdx) {
        this.listIdx = listIdx;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageuri() {
        return imageuri;
    }

    public void setImageuri(String imageuri) {
        this.imageuri = imageuri;
    }
}
*/


