package com.example.registerloginexample.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.registerloginexample.R;
import com.example.registerloginexample.repository.Item;
import com.example.registerloginexample.room.book.BookData;

import java.util.ArrayList;
import java.util.List;

public class BookDataAdapter extends BaseAdapter {
    private List<BookData> bookDataList = new ArrayList<>();
    private Context mContext;

    public BookDataAdapter(Context context){
        mContext = context;
    }
    @Override
    public int getCount() {
        return bookDataList.size();
    }

    @Override
    public BookData getItem(int i) {
        return bookDataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = (view != null)  ? view :LayoutInflater.from(mContext).inflate(R.layout.recyclerview_result,null);
        BookData bookData = getItem(i);
        ImageView mIvPoster = v.findViewById(R.id.iv_poster);
        TextView mTvTitle = v.findViewById(R.id.tv_title);
        TextView mTvAuthor = v.findViewById(R.id.tv_pub_data);
        TextView mTvPublisher = v.findViewById(R.id.tv_director);
        TextView mTvDescription = v.findViewById(R.id.tv_actor);
        mTvTitle.setText(Html.fromHtml(bookData.getTitle()));
        mTvAuthor.setText(bookData.getAuthor());
        mTvPublisher.setText(Html.fromHtml(bookData.getPublisher()));
        mTvDescription.setText(Html.fromHtml(bookData.getDescription()));

        //bookViewHolder.mIvPoster.setImageResource(R.drawable.book);
        Glide.with(mContext).load(bookData.getImage()).into(mIvPoster);
        return v;
    }

    public void setBookDataList(List<BookData> bookDataList){
        this.bookDataList = bookDataList;
        notifyDataSetChanged();
    }

    public List<BookData> getBookDataList(){
        return this.bookDataList;
    }
}
