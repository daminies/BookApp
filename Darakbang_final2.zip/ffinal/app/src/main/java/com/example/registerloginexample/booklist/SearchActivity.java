package com.example.registerloginexample.booklist;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;



import com.example.registerloginexample.R;
import com.example.registerloginexample.util.ActivityUtils;
import com.example.registerloginexample.booklist.SearchFragment;
import com.example.registerloginexample.booklist.SearchPresenter;

public class SearchActivity extends AppCompatActivity {

    private static final String TAG = SearchActivity.class.getName();

    private SearchPresenter mSearchPresenter;

    // private Toolbar mToolBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

       /* Toolbar mToolBar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(mToolBar);
        getSupportActionBar().setTitle(R.string.app_name);
        mToolBar.setTitleTextColor(getResources().getColor(R.color.white)); */

        SearchFragment searchFragment = (SearchFragment) getSupportFragmentManager().findFragmentById(R.id.contentFrame);
        searchFragment = searchFragment.newInstance();
        ActivityUtils.addFragmentToActivity(getSupportFragmentManager(), searchFragment, R.id.contentFrame);

        String baseUrl = getResources().getString(R.string.baseUrl);
        mSearchPresenter = new SearchPresenter(searchFragment, baseUrl);
    }
}
