package com.example.registerloginexample.room.bookList;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.registerloginexample.room.book.BookDao;
import com.example.registerloginexample.room.book.BookData;

@Database(entities = {BookListData.class}, version =  1)
public abstract class BookListDatabase extends RoomDatabase {
    private static BookListDatabase bookDatabase;
    public abstract BookListDao bookListDao();

    public static BookListDatabase getInstance(Context context){
        if(bookDatabase==null){
            bookDatabase = Room.databaseBuilder(context, BookListDatabase.class,"bookList-db")
                    .build();
        }
        return bookDatabase;
    }
}
