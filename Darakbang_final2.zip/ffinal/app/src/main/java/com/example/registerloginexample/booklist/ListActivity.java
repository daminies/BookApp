package com.example.registerloginexample.booklist;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.registerloginexample.R;
import com.example.registerloginexample.adapter.BookListDataAdapter;
import com.example.registerloginexample.room.book.BookDatabase;
import com.example.registerloginexample.room.bookList.BookListData;
import com.example.registerloginexample.room.bookList.BookListDataProcess;
import com.example.registerloginexample.room.bookList.BookListDatabase;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    ArrayList<String> bookdata = new ArrayList<String>();
    BookListDataAdapter adapter;
    BookListDataProcess bookListDataProcess;
    ArrayList<Listbook> booklist = new ArrayList<Listbook>();
    ListView listView;
    final int BOOK_INFO = 21;
    final int NEW_BOOK = 22;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        tv = (TextView)findViewById(R.id.tv);
        setTitle("다락방");
        setListView();
        bookListDataProcess = new BookListDataProcess(this);
    }


    public void onClick(View v)
    {
        Intent intent = new Intent(ListActivity.this,SubActivity.class);
        intent.putExtra("booklist",bookdata);
        startActivityForResult(intent,NEW_BOOK);
    }
    public void setListView()
    {
        listView = (ListView)findViewById(R.id.listview);

        //데이터를 만들고
        //data.add("무언가");
        //bookdata.add("읽고있는 책");
        //bookdata.add("읽고싶은 책");
        //data.add("읽");

        //어댑터 만듬
        adapter = new BookListDataAdapter(this);
        listView.setAdapter(adapter);
        BookListDatabase.getInstance(this).bookListDao().getAllData().observe(this, bookListData -> {
                adapter.setBookListDataList(bookListData);
                tv.setText("책 리스트("+adapter.getCount()+"개)");
        });
        //꾹 눌렀을때 삭제
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, final View view, final int position, long id) {

                //정보를 삭제하는지 묻는 대화상자 나타남
                AlertDialog.Builder dlg = new AlertDialog.Builder(view.getContext());
                dlg.setTitle("삭제확인")
                        .setIcon(R.drawable.book)
                        .setMessage("선택한 리스트를 정말 삭제하시겠습니까?")
                        .setNegativeButton("취소",null)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                bookListDataProcess.deleteData(adapter.getItem(position).id);
                                tv.setText("책 리스트("+bookdata.size()+"개)");
                                Snackbar.make(view,"삭제되었습니다.",2000).show();
                            }
                        })
                        .show();
                return true;
            }
        });

        //클릭시 리스트 만들기가 나타남
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(ListActivity.this,SubActivity.class);
                intent.putExtra("id", adapter.getItem(position).id);
                startActivity(intent);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == NEW_BOOK)
        {
            if(resultCode == RESULT_OK)
            {

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
