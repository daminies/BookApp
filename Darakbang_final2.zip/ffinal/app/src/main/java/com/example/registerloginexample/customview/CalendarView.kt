package com.jaeyoung.CustomCalendarView

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.registerloginexample.R
import com.example.registerloginexample.calendar.CalendarClickListener
import com.example.registerloginexample.room.calendar.CalendarDatabase
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.top_layout.view.*
import java.text.SimpleDateFormat
import java.util.*

class CalendarView : LinearLayout {
    private val dayOfWeek = mutableListOf("Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat")
    private var calendarAdapter = CalendarAdapter(context)
    private val cal = Calendar.getInstance()
    private var year = cal.get(Calendar.YEAR)
    private var month = cal.get(Calendar.MONTH)
    private var selCal = Calendar.getInstance()
    private var currentDate = cal
    private var calendarClickListener : CalendarClickListener? = null;

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
//        val attrsArray = context.theme.obtainStyledAttributes(attrs, R.styleable.RowView, 0, 0)
//        rowCount = attrsArray.getInt(R.styleable.RowView_rowCount, 3)
//        itemMargin = attrsArray.getInt(R.styleable.RowView_itemMargin, 30)
        init(context)

    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    private fun init(context: Context) {
        orientation = VERTICAL
        cal.set(year, month, 1, 0, 0, 0)
        selCal.set(year, month, 1, 0, 0, 0)
        addView(createTopDateView())
        addView(createTopView())
        addView(createGridView())

    }

    private fun createTopView(): LinearLayout {
        val l1 = LinearLayout(context)
        val lp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l1.orientation = HORIZONTAL
        l1.layoutParams = lp
        l1.weightSum = 7F
        for (i in 0 until dayOfWeek.size) {
            if ((i + 1) % 7 == 0) l1.addView(createTextView(dayOfWeek[i], true))
            else l1.addView(createTextView(dayOfWeek[i], false))
        }
        l1.requestLayout()
        return l1
    }

    private fun createTopDateView(): View {
        val inflator = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val topDateView = inflator.inflate(R.layout.top_layout, null)
        topDateView.date_tv.text = getDate(cal)
        topDateView.pre_btn.setOnClickListener {
            downToMonth()
            topDateView.date_tv.text = getDate(cal)
            calendarAdapter.calUpdate(cal)
            loadData()
        }
        topDateView.next_btn.setOnClickListener {
            upToMonth()
            topDateView.date_tv.text = getDate(cal)
            calendarAdapter.calUpdate(cal)
            loadData()
        }
        return topDateView
    }

    fun loadData(){
        val a = Observable.just(CalendarDatabase.getDatabase(context))
                .subscribeOn(Schedulers.io())
                .subscribe {
                    if(it!=null){
                        val data = it.calendarDao().getData(cal.get(Calendar.YEAR).toString(),(cal.get(Calendar.MONTH)+1).toString())
                        var num = 0
                        data.forEach {
                            if(it.statusFirst == 2) num++
                            if(it.statusSecond == 2) num++
                        }
                        val activity = context as Activity
                        activity.runOnUiThread {
                            bookNumTv.text = num.toString()+"권"
                        }

                        calendarAdapter.setData(data)
                    }
                    else
                        calendarAdapter.notifyDataSetChanged()
                }
    }

    private fun createGridView(): GridView {
        val gridView = GridView(context)
        val lp =
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        gridView.setOnItemClickListener { adapterView, view, position, l ->
            if(adapterView.getItemAtPosition(position)!=0){
                selCal.set(year, month, adapterView.getItemAtPosition(position) as Int, 0, 0, 0)
                calendarClickListener?.onClick(getDateFull(selCal),position)


            }
        }
        val dp = pixelToDp(1F)
        gridView.let {
            it.layoutParams = lp
            it.numColumns = 7
            it.adapter = calendarAdapter
        }
        return gridView
    }

    fun getCal():Calendar{
        return selCal
    }


    private fun createTextView(text: String, lastCheck: Boolean): TextView {
        val lp = LayoutParams(
            0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1F
        )
        val textView = TextView(context)
        textView.text = text
        if (lastCheck) textView.setBackgroundResource(R.drawable.calendar_top_square_last)
        else textView.setBackgroundResource(R.drawable.calendar_top_square)
        textView.textAlignment = View.TEXT_ALIGNMENT_CENTER
        textView.layoutParams = lp
        textView.setTextColor(Color.parseColor("#ffffff"))
        return textView
    }

    private fun pixelToDp(value: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        ).toInt()
    }

    private fun getDate(cal:Calendar): String {
        val simpleFormat = SimpleDateFormat("yyyy년 M월")
        return simpleFormat.format(cal.time)
    }

    private fun getDateFull(cal:Calendar): String {
        val simpleFormat = SimpleDateFormat("yyyy.MM.dd")
        return simpleFormat.format(cal.time)
    }

    private fun downToMonth() {
        month -= 1
        if (month <= 0) {
            month = 12
            year -= 1
        }
        cal.set(year, month, 1, 0, 0, 0)
    }

    private fun upToMonth() {
        month += 1
        if (month > 12) {
            month = 1
            year += 1
        }
        cal.set(year, month, 1, 0, 0, 0)
    }

    fun setClickListener(onClick : CalendarClickListener){
        calendarClickListener = onClick
    }
}