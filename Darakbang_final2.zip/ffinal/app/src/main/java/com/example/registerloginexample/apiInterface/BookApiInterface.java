package com.example.registerloginexample.apiInterface;

import com.example.registerloginexample.repository.BookInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface BookApiInterface {

    @Headers({"X-Naver-Client-Id: SSTGn6IPQvoN2gwLTyLJ", "X-Naver-Client-Secret: OLBQZ0IQKA"})
    @GET("/v1/search/book.json")
    Call<BookInfo> getBookList(@Query("query") String title, @Query("display") int displaySize,
                               @Query("start") int startPosition);

}
