package com.example.registerloginexample.room.book;

import android.app.Activity;
import android.content.Context;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class BookDataProcess {
    private Context mContext;
    private Activity mActivity;
    public BookDataProcess(Context context){
        mContext = context;
        mActivity = (Activity) mContext;
    }

    public void insertData(BookData bookData){
        Observable.just(BookDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookDatabase bookDatabase) {
                        bookDatabase.bookDao().insert(bookData);
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }

    public void deleteAllData(){
        Observable.just(BookDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookDatabase bookDatabase) {
                        bookDatabase.bookDao().deleteAll();
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }

    public void deleteData(long id){
        Observable.just(BookDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookDatabase bookDatabase) {
                        bookDatabase.bookDao().deleteData(id);
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }
}
