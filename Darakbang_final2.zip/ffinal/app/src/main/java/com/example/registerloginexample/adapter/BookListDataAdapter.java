package com.example.registerloginexample.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.registerloginexample.R;
import com.example.registerloginexample.room.bookList.BookListData;
import com.example.registerloginexample.room.bookList.Converters;


import java.util.ArrayList;
import java.util.List;

public class BookListDataAdapter extends BaseAdapter {
    List<BookListData> bookListDataList = new ArrayList<>();
    Context mContext;
    public BookListDataAdapter(Context context){
        mContext = context;
    }
    @Override
    public int getCount() {
        return bookListDataList.size();
    }

    @Override
    public BookListData getItem(int i) {
        return bookListDataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = (view != null)  ? view : LayoutInflater.from(mContext).inflate(R.layout.list_item_booklist,null);
        TextView groupTv = v.findViewById(R.id.groupTv);
        TextView bookNumTv = v.findViewById(R.id.bookNumTv);
        bookNumTv.setText(Converters.fromString(getItem(i).bookListData).size()+"개");
        groupTv.setText(getItem(i).groupName);
        return v;
    }

    public void setBookListDataList(List<BookListData> bookListDataList){
        this.bookListDataList = bookListDataList;
        notifyDataSetChanged();
    }
}
