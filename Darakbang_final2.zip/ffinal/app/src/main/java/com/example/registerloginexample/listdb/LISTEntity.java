package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class LISTEntity {
        @PrimaryKey(autoGenerate = true)
        public Integer listId;

        //public static BreakIterator listName;
        public String listName;


        public Integer getListId() {
                return listId;
        }

        public void setListId(Integer listId) {
                this.listId = listId;
        }

        public String getListName() {
                return listName;
        }

        public void setListName(String listName) {
                this.listName = listName;
        }

}
*/