package com.example.registerloginexample.calendar

interface CalendarClickListener {
    fun onClick(date:String , position : Int)
}