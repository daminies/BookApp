package com.example.registerloginexample.booklist;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.registerloginexample.R;
import com.example.registerloginexample.adapter.BookDataAdapter;
import com.example.registerloginexample.room.book.BookData;
import com.example.registerloginexample.room.book.BookDataProcess;
import com.example.registerloginexample.room.book.BookDatabase;
import com.example.registerloginexample.room.bookList.BookListData;
import com.example.registerloginexample.room.bookList.BookListDataProcess;
import com.example.registerloginexample.room.bookList.BookListDatabase;
import com.example.registerloginexample.room.bookList.Converters;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class SubActivity extends AppCompatActivity {
    EditText etname;
    Listbook boo;
    private Button btn_bookadd;
    private Button btnCancel;
    private Button btnAdd;
    private BookDataAdapter bookDataAdapter;
    private BookDataProcess bookDataProcess;
    private BookListDataProcess bookListDataProcess;
    long id;
    @Override
    protected void onDestroy() {
        super.onDestroy();
        delData();
    }

    private void delData(){
        bookDataProcess.deleteAllData();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        etname = (EditText) findViewById(R.id.etname);
        bookDataProcess = new BookDataProcess(this);
        bookListDataProcess = new BookListDataProcess(this);
        setTitle("리스트 만들기");
        ListView listView = findViewById(R.id.listView);
        bookDataAdapter = new BookDataAdapter(this);
        listView.setAdapter(bookDataAdapter);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, final View view, final int position, long id) {

                //정보를 삭제하는지 묻는 대화상자 나타남
                AlertDialog.Builder dlg = new AlertDialog.Builder(view.getContext());
                dlg.setTitle("삭제확인")
                        .setIcon(R.drawable.book)
                        .setMessage("선택한 책을 정말 삭제하시겠습니까?")
                        .setNegativeButton("취소",null)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                bookDataProcess.deleteData(bookDataAdapter.getItem(position).getId());
                                Snackbar.make(view,"삭제되었습니다.",2000).show();
                            }
                        })
                        .show();
                return true;
            }
        });
        id = getIntent().getLongExtra("id",0);
        if(id!=0){
            BookListDatabase.getInstance(this).bookListDao().getData(id).observe(this, new androidx.lifecycle.Observer<BookListData>() {
                @Override
                public void onChanged(BookListData bookListData) {
                    etname.setText(bookListData.groupName);
                    List<BookData> bookDataList = Converters.fromString(bookListData.bookListData);
                    for(BookData bookData :bookDataList){
                        bookDataProcess.insertData(bookData);
                    }
                }
            });
        }

        BookDatabase.getInstance(this).bookDao().getAllData().observe(this, bookData -> {
            bookDataAdapter.setBookDataList(bookData);
        });



     /*   btn_bookadd = findViewById(R.id.btn_bookadd);
        btnCancel = findViewById(R.id.btnCancel);
        btnAdd = findViewById(R.id.btnAdd);

        btn_bookadd.setOnClickListener(new View.OnClickListener() { // 회원가입 버튼 클릭시 수행
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubActivity.this, SearchActivity.class);
                startActivity(intent);

            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() { // 회원가입 버튼 클릭시 수행
            @Override
            public void onClick(View v) {
                finish();
            }
        });

      btnAdd.setOnClickListener(new View.OnClickListener() { // 회원가입 버튼 클릭시 수행
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                intent.putExtra("newbook",boo);  //Parcelable한 Restaurant를 첨부
                setResult(RESULT_OK,intent);
                finish();
            }
        });*/



    }


   public void onClick(View v)
    {
        if (v.getId() == R.id.btnCancel)
        {
            finish();
        }
        else if (v.getId() == R.id.btn_bookadd)
        {
            Intent intent = new Intent(SubActivity.this, SearchActivity.class);
            startActivity(intent);
        }
        else
        {
            if(!etname.getText().toString().equals("")){
                if(id==0) bookListDataProcess.insertData(bookDataAdapter.getBookDataList(),etname.getText().toString());
                else bookListDataProcess.updateData(id,bookDataAdapter.getBookDataList(),etname.getText().toString());
            }else Toast.makeText(this,"리스트명을 입력해주세요",Toast.LENGTH_SHORT).show();
        }
    }



    /*public void setcategory_num(int n)
    {
        boo = new Listbook(etname.getText().toString(), n);
    }*/


}
