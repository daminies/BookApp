package com.example.registerloginexample.room.bookList;

import android.app.Activity;
import android.content.Context;

import com.example.registerloginexample.room.book.BookData;
import com.example.registerloginexample.room.book.BookDatabase;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class BookListDataProcess {
    private Context mContext;
    private Activity mActivity;
    public BookListDataProcess(Context context){
        mContext = context;
        mActivity = (Activity) mContext;
    }

    public void insertData(List<BookData> bookDataList, String groupName){
        Observable.just(BookListDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookListDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookListDatabase bookDatabase) {
                        bookDatabase.bookListDao().insertData(new BookListData(System.currentTimeMillis(), Converters.fromArrayList(bookDataList),groupName));
                        mActivity.finish();
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }

    public void deleteData(long id){
        Observable.just(BookListDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookListDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookListDatabase bookDatabase) {
                        bookDatabase.bookListDao().deleteData(id);
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }

    public void updateData(long id,List<BookData> bookDataList, String groupName){
        Observable.just(BookListDatabase.getInstance(mContext))
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<BookListDatabase>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                    @Override
                    public void onNext(@io.reactivex.annotations.NonNull BookListDatabase bookDatabase) {
                        bookDatabase.bookListDao().updateData(new BookListData(id, Converters.fromArrayList(bookDataList), groupName));
                        mActivity.finish();
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                    @Override
                    public void onComplete() { }
                });
    }
}
