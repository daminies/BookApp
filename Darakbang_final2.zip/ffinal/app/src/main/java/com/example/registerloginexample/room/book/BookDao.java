package com.example.registerloginexample.room.book;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface BookDao {
    @Query("SELECT * FROM BookData")
    LiveData<List<BookData>> getAllData();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(BookData bookData);

    @Query("DELETE FROM BookData WHERE `id`=:id")
    void deleteData(long id);

    @Query("DELETE FROM BookData")
    void deleteAll();
}
