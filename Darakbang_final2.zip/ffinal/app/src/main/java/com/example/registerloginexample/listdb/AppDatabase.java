package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(version = 1, entities = {LISTEntity.class, BOOKEntity.class})
public abstract class AppDatabase extends RoomDatabase {
    abstract public BOOKDao bookDao();
    abstract public LISTDao listDao();
    abstract public BOOKLISTDao booklistDao();
}*/
