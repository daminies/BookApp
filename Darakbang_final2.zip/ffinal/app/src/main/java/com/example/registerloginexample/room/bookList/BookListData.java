package com.example.registerloginexample.room.bookList;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class BookListData {
    @PrimaryKey
    public long id;
    public String bookListData;
    public String groupName;

    public BookListData(long id, String bookListData, String groupName ){
        this.id = id;
        this.bookListData = bookListData;
        this.groupName = groupName;
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBookListData() {
        return bookListData;
    }

    public void setBookListData(String bookListData) {
        this.bookListData = bookListData;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }


}
