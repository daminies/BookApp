package com.example.registerloginexample.room.calendar

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface CalendarDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCal(calendarData: CalendarData?)

    @Update
    fun updateCal(calendarData: CalendarData?)

    @Query("SELECT * FROM calendardata WHERE `year`=:year AND `month`=:month AND `position`=:position")
    fun getData(year:String,month:String,position:Int) : CalendarData

    @Query("SELECT * FROM calendardata WHERE `year`=:year AND `month`=:month")
    fun getData(year:String,month:String) : MutableList<CalendarData>

    @Query("SELECT * FROM calendardata")
    fun getAllData() : MutableList<CalendarData>
}