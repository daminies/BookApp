package com.example.registerloginexample.booklist;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.registerloginexample.R;
import com.example.registerloginexample.adapter.BookAdapter;
import com.example.registerloginexample.customtab.CustomTabServiceController;
import com.example.registerloginexample.listener.EndlessRecyclerViewScrollListener;
import com.example.registerloginexample.listener.RecyclerItemClickListener;
import com.example.registerloginexample.repository.Item;
import com.example.registerloginexample.room.book.BookData;
import com.example.registerloginexample.room.book.BookDatabase;

import java.util.ArrayList;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import static com.example.registerloginexample.util.Constants.MOVIE_DISPLAY_SIZE;

public class SearchFragment extends Fragment implements SearchContract.View, View.OnClickListener {

    private static final String TAG = SearchFragment.class.getName();

    private SearchPresenter mPresenter;

    private RecyclerView mRecyclerView;

    private BookAdapter mBookAdapter;

    private RecyclerView.LayoutManager mLayoutManager;

    private EditText mEtKeyword;

    private Button mBtnSearch;

    private InputMethodManager mInputMethodManager;

    private EndlessRecyclerViewScrollListener mEndlessRecyclerViewScrollListener;

    public static SearchFragment newInstance() {
        return new SearchFragment();
    }

    public SearchFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.search_fragment, container,
                false);
        setupRecyclerView(root);

        mEtKeyword = root.findViewById(R.id.et_keyword);
        mBtnSearch = root.findViewById(R.id.btn_search);
        mBtnSearch.setOnClickListener(this);

        mInputMethodManager = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        mPresenter.start();
    }

    @Override
    public void setPresenter(@NonNull SearchContract.Presenter presenter) {
        mPresenter = (SearchPresenter) presenter;
    }

    private void setupRecyclerView(View view) {
        mRecyclerView = view.findViewById(R.id.result_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(),
                mRecyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {
                Item item = mBookAdapter.getItem(position);
                BookData bookData = new BookData(System.currentTimeMillis(),item.getTitle(),item.getImage(),item.getSubtitle(),item.getAuthor(),item.getPublisher(),item.getDescription());
                Observable.just(BookDatabase.getInstance(getContext()))
                        .subscribeOn(Schedulers.io())
                        .subscribe(new Observer<BookDatabase>() {
                            @Override
                            public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) { }

                            @Override
                            public void onNext(@io.reactivex.annotations.NonNull BookDatabase bookDatabase) {
                                bookDatabase.bookDao().insert(bookData);
                                getActivity().finish();
                            }

                            @Override
                            public void onError(@io.reactivex.annotations.NonNull Throwable e) {}
                            @Override
                            public void onComplete() { }
                        });
                //showBookPage(position);
            }
        }));

        mEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) mLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                mPresenter.getBooks(mEtKeyword.getText().toString(), page * MOVIE_DISPLAY_SIZE + 1);
            }
        };
        mRecyclerView.addOnScrollListener(mEndlessRecyclerViewScrollListener);
        ArrayList<Item> bookInfoArrayList = new ArrayList<>();

        mBookAdapter = new BookAdapter(bookInfoArrayList,getContext());
        mRecyclerView.setAdapter(mBookAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_search:
                mInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                mEndlessRecyclerViewScrollListener.resetState();
                mPresenter.startSearch(mEtKeyword.getText().toString());
                break;
        }
    }

    @Override
    public void showEmptyField() {
        Toast.makeText(getContext(), "검색어를 입력해주세요", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNotFindItem() {
        mBookAdapter.clearItems();
        Toast.makeText(getContext(), "\'" + mEtKeyword.getText().toString()
                + "\' 검색결과는 없습니다.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showBookPage(int position) {

        String url = mBookAdapter.getItem(position).getLink();
        Intent intent = setupCustomTabs(url);
        startActivity(intent);
    }

    private Intent setupCustomTabs(String url) {
        CustomTabServiceController customTabServiceController = new CustomTabServiceController(getContext(), url);
        customTabServiceController.bindCustomTabService();
        Intent customTabIntent = customTabServiceController.createCustomTabIntent(null,
                Color.rgb(38,182,172));
        customTabServiceController.unbindCustomTabService();
        return customTabIntent;
    }

    @Override
    public void showMoreBooks(ArrayList<Item> items) {
        mBookAdapter.addItems(items);
    }

    @Override
    public void showNewBooks(ArrayList<Item> items) {
        mLayoutManager.scrollToPosition(0);
        mBookAdapter.clearAndAddItems(items);
    }
}