package com.jaeyoung.CustomCalendarView

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.example.registerloginexample.R
import com.example.registerloginexample.room.calendar.CalConverter
import com.example.registerloginexample.room.calendar.CalendarData
import com.example.registerloginexample.room.calendar.CalendarDatabase
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_calendar_detail.*
import kotlinx.android.synthetic.main.item_layout.view.*
import java.util.*

class CalendarAdapter(context: Context) : BaseAdapter() {
    private val day = mutableListOf<Int>()
    private var mContext : Context = context
    private var cal = Calendar.getInstance()
    private var lastWeekDay = 0
    private var firstWeekDay = 0
    private var dayOfMonth = 0
    private var DAY_OF_WEEK = 7
    private var colorFlag = true
    private var calendarData : MutableList<CalendarData> = mutableListOf()

    init {
        setCal()
    }

    override fun getView(position: Int, view: View?, p2: ViewGroup?): View {
        val inflator = mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val mView = view ?: inflator.inflate(R.layout.item_layout,null)
        val img01 = mView.findViewById<ImageView>(R.id.image_01)
        val img02 = mView.findViewById<ImageView>(R.id.image_02)
        Glide.with(mContext).load("").into(img01)
        Glide.with(mContext).load("").into(img02)
        if(calendarData.size >0){
            if(calendarData.any { it.position == position }){
                CalConverter().stringToCal(calendarData.filter { it.position == position}[0].bookDataList).forEachIndexed { index, bookData ->
                    if(bookData!=null){
                        when(index){
                            0 -> Glide.with(mContext).load(bookData.image).into(img01)
                            1 -> Glide.with(mContext).load(bookData.image).into(img02)
                        }
                    }
                }
            }

        }
        when {
            (position+1)%7==0 -> mView.day_tv.setTextColor(Color.BLUE)
            position%7==0 -> mView.day_tv.setTextColor(Color.RED)
            else -> mView.day_tv.setTextColor(Color.BLACK)
        }
        //if((position+1)%7==0) mView.setBackgroundResource(R.drawable.calendar_item_square_last)
//        if(colorFlag) mView.setBackgroundColor(Color.YELLOW)
//        else mView.setBackgroundColor(Color.BLUE)
//        if((position+1)%7==0) colorFlag = !colorFlag
        if(day[position]!=0) {

            val todayCal = Calendar.getInstance()
            if(cal.get(Calendar.YEAR)==todayCal.get(Calendar.YEAR)&&cal.get(Calendar.MONTH)==todayCal.get(Calendar.MONTH)&&todayCal.get(Calendar.DATE)==day[position]){
                mView.test.setBackgroundColor(mContext.getColor(R.color.colorPrimary))
            } else
                mView.test.setBackgroundColor(mContext.getColor(R.color.white))
            mView.cal_layout.visibility = View.VISIBLE
            mView.day_tv.text = day[position].toString()
        }
        else mView.day_tv.text = ""
        return mView
    }

    override fun getItem(p0: Int): Any {
        return day[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return day.size
    }

    fun calUpdate(cal : Calendar){
        this.cal = cal
        setCal()
    }

    private fun setCal(){
        day.clear()
        cal.set(Calendar.DATE,1)
        firstWeekDay = cal.get(Calendar.DAY_OF_WEEK)-1
        cal.set(Calendar.DATE,cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        dayOfMonth = cal.get(Calendar.DATE)
        lastWeekDay = DAY_OF_WEEK-cal.get(Calendar.DAY_OF_WEEK)
        var count = 1
        for(i in 0 until dayOfMonth+firstWeekDay+lastWeekDay){
            if(i>=firstWeekDay&&i<firstWeekDay+cal.getActualMaximum(Calendar.DAY_OF_MONTH)){
                day.add(count)
                count++
            } else day.add(0)
        }
        notifyDataSetChanged()
    }

    fun setData(data : MutableList<CalendarData>){
        val activity = mContext as Activity
        activity.runOnUiThread {
            calendarData = data
            notifyDataSetChanged()
        }

    }
}