package com.example.registerloginexample.room.book;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {BookData.class}, version =  1)
public abstract class BookDatabase extends RoomDatabase {
    private static BookDatabase bookDatabase;
    public abstract BookDao bookDao();

    public static BookDatabase getInstance(Context context){
        if(bookDatabase==null){
            bookDatabase = Room.databaseBuilder(context,BookDatabase.class,"book-db")
                    .build();
        }
        return bookDatabase;
    }
}
