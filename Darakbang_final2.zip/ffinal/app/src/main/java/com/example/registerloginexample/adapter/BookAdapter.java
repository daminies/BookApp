package com.example.registerloginexample.adapter;

import android.content.Context;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.registerloginexample.MyApplication;
import com.example.registerloginexample.R;
import com.example.registerloginexample.repository.Item;

import java.util.ArrayList;

;

public class BookAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

   RequestOptions options = new RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL);
   private Context mContext;

    private final static String TAG = BookAdapter.class.getName();

    private ArrayList<Item> mBookInfoArrayList;

    public BookAdapter(ArrayList<Item> bookInfoArrayList, Context context) {
        mBookInfoArrayList = bookInfoArrayList;
        mContext=  context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.recyclerview_result, parent, false);
        return new BookViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        BookViewHolder bookViewHolder = (BookViewHolder) holder;

        Item item = mBookInfoArrayList.get(position);
        bookViewHolder.mTvTitle.setText(Html.fromHtml(item.getTitle()));
        bookViewHolder.mTvAuthor.setText(item.getAuthor());
        bookViewHolder.mTvPublisher.setText(Html.fromHtml(item.getPublisher()));
        bookViewHolder.mTvDescription.setText(Html.fromHtml(item.getDescription()));

        //bookViewHolder.mIvPoster.setImageResource(R.drawable.book);
        Glide.with(mContext).load(item.getImage()).into(bookViewHolder.mIvPoster);

       /* try {
            Glide.with(MyApplication.getContext())
                    .load(R.drawable.book)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(bookViewHolder.mIvPoster);
        } catch (NullPointerException e) {
            Log.d(TAG, "Not Found Image Url");
        }*/

    }

    @Override
    public int getItemCount() {
        return mBookInfoArrayList.size();
    }

    public Item getItem(int position) {
        return mBookInfoArrayList.get(position);
    }

    public void addItems(ArrayList<Item> items) {
        mBookInfoArrayList.addAll(items);
        notifyDataSetChanged();
    }

    public void clearItems() {
        mBookInfoArrayList.clear();
        notifyDataSetChanged();
    }

    public void clearAndAddItems(ArrayList<Item> items) {
        mBookInfoArrayList.clear();
        addItems(items);
        notifyDataSetChanged();
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {

        private ImageView mIvPoster;
        private TextView mTvTitle;
        private TextView mTvAuthor;
        private TextView mTvPublisher;
        private TextView mTvDescription;

        BookViewHolder(View view) {
            super(view);
            mIvPoster = view.findViewById(R.id.iv_poster);
            mTvTitle = view.findViewById(R.id.tv_title);
            mTvAuthor = view.findViewById(R.id.tv_pub_data);
            mTvPublisher = view.findViewById(R.id.tv_director);
            mTvDescription = view.findViewById(R.id.tv_actor);
        }

        public ImageView getImage() {
            return mIvPoster;
        }

    }
}
