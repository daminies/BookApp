package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

public interface LISTDao {

    @Query("SELECT * FROM LISTEntity")
    abstract List<LISTEntity> getAll();

    @Query("SELECT * FROM LISTEntity WHERE listId IN (:listId)")
    List<LISTEntity> loadAllByIds(int[] listId);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertBooks(LISTEntity... listEntities);

    @Update
    public void updateBooks(LISTEntity... listEntities);

    @Delete
    public void deleteBooks(LISTEntity... listEntities);

}*/