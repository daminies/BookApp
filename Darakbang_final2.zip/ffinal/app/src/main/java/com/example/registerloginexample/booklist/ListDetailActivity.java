package com.example.registerloginexample.booklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.registerloginexample.R;

public class ListDetailActivity extends AppCompatActivity {
    TextView name;
    long id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_detail);
        setTitle("리스트 정보 보기");
        name = (TextView)findViewById(R.id.tv_list_result);
        id = getIntent().getLongExtra("id",0);


    }

    public void onClick(View v){
        Intent intent = getIntent();
        Listbook boo = intent.getParcelableExtra("bookinfo");
    }


}
