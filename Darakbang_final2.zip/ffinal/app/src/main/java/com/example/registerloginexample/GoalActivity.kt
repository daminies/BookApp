package com.example.registerloginexample

import android.animation.ValueAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.registerloginexample.room.calendar.CalConverter
import com.example.registerloginexample.room.calendar.CalendarDatabase
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_goal.*
import kotlin.math.roundToInt

class GoalActivity : AppCompatActivity() {
    private val STATUS_FINISH = 2
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal)
        loadData()
    }

    private fun loadData() {
        val a = Observable.just(CalendarDatabase.getDatabase(this))
                .subscribeOn(Schedulers.io())
                .subscribe {
                    var finishCT = 0
                    var bookCT = 0
                    it.calendarDao().getAllData().forEach {
                        CalConverter().stringToCal(it.bookDataList).forEach {
                            if (it != null)
                                bookCT++
                        }
                        if (it.statusFirst == STATUS_FINISH) finishCT++
                        if (it.statusSecond == STATUS_FINISH) finishCT++
                    }
                    runOnUiThread {
                        registerCT_tv.text = bookCT.toString() + "권"
                        finishCT_tv.text = finishCT.toString() + "권"
                    }
                    Handler(Looper.getMainLooper()).post {
                        setPr((finishCT / +bookCT.toFloat() * 100).roundToInt())
                    }
                }
    }

    private fun setPr(percent: Int) {
        ValueAnimator.ofInt(0, percent).apply {
            duration = 1500
            addUpdateListener {
                runOnUiThread {
                    cpb_circlebar.progress = it.animatedValue as Int
                }
            }
            start()
        }

    }
}