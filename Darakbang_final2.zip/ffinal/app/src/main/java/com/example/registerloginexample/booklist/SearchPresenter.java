package com.example.registerloginexample.booklist;

import androidx.annotation.NonNull;

import com.example.registerloginexample.apiInterface.BookApiInterface;
import com.example.registerloginexample.repository.BookInfo;
import com.example.registerloginexample.util.RetrofitClient;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.example.registerloginexample.util.Constants.MOVIE_DISPLAY_SIZE;

public class SearchPresenter implements SearchContract.Presenter {

    private static final String TAG = SearchPresenter.class.getName();

    private SearchContract.View mSearchView;

    private Retrofit mRetrofit;
    private BookApiInterface mBookApiInterface;
    private Call<BookInfo> mCallBookList;
    private int mPageNo;

    public SearchPresenter(@NonNull SearchContract.View searchView, String baseUrl) {
        mRetrofit = RetrofitClient.getClient(baseUrl);
        mBookApiInterface = mRetrofit.create(BookApiInterface.class);

        mSearchView = searchView;
        mSearchView.setPresenter(this);
    }

    @Override
    public void start() {

    }

    @Override
    public void startSearch(String title) {
        if (title.isEmpty()) {
            mSearchView.showEmptyField();
        } else {
            mPageNo = 1;
            getBooks(title, 1);
        }
    }

    @Override
    public void getBooks(String title, int startPosition) {
        if ((mPageNo != -1 || startPosition == 1) && startPosition < 1001) {
            mPageNo = startPosition;
            mCallBookList = mBookApiInterface.getBookList(title, MOVIE_DISPLAY_SIZE, startPosition);
            mCallBookList.enqueue(mRetrofitCallback);
        }
    }

    private Callback<BookInfo> mRetrofitCallback = new Callback<BookInfo>() {

        @Override
        public void onResponse(Call<BookInfo> call, Response<BookInfo> response) {
            BookInfo result = response.body();
            if (result.getItems() == null) {
                mPageNo = -1;
                return;
            }
            if (result.getItems().size() == 0) {
                mSearchView.showNotFindItem();
            } else if (mPageNo <= MOVIE_DISPLAY_SIZE) {
                mSearchView.showNewBooks(new ArrayList<>(result.getItems()));
            } else {
                mSearchView.showMoreBooks(new ArrayList<>(result.getItems()));
            }
            if (result.getItems().size() < MOVIE_DISPLAY_SIZE) {
                mPageNo = -1;
            }
        }

        @Override
        public void onFailure(Call<BookInfo> call, Throwable t) {
            t.printStackTrace();
        }

    };

}