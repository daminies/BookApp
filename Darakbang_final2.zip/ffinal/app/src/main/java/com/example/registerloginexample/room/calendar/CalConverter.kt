package com.example.registerloginexample.room.calendar

import androidx.room.TypeConverter
import com.example.registerloginexample.room.book.BookData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Array

class CalConverter{
    @TypeConverter
    fun stringToCal(value: String?): MutableList<BookData?> {
        val listType = object : TypeToken<MutableList<BookData?>>() {}.type
        return Gson().fromJson<MutableList<BookData?>>(value, listType)
    }

    @TypeConverter
    fun calToString(list: MutableList<BookData?>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}