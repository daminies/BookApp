package com.example.registerloginexample.listdb;/*package com.example.registerloginexample.listdb;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BOOKDao {
    @Query("SELECT * FROM BOOKEntity")
    abstract List<BOOKEntity> getAll();

    @Query("SELECT * FROM BOOKEntity WHERE listIdx IN (:listIdx)")
    List<BOOKEntity> loadAllByIds(int[] listIdx);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertBooks(BOOKEntity... bookEntities);


    @Update
    public void updateBooks(BOOKEntity... bookEntities);

    @Delete
    public void deleteBooks(BOOKEntity... bookEntities);


}*/
